import TelegramBot from 'node-telegram-bot-api';
import InstagramDL from 'instagram-url-downloader';
import dotenv from 'dotenv';

dotenv.config();

const bot = new TelegramBot(process.env.TELEGRAM_BOT_TOKEN, { polling: true });

// Welcome message handler
bot.onText(/\/start/, (msg) => {
  const chatId = msg.chat.id;
  bot.sendMessage(
    chatId,
    'Welcome! 👋\nSend me an Instagram Reel link, and I\'ll download it for you.'
  );
});

// Help message handler
bot.onText(/\/help/, (msg) => {
  const chatId = msg.chat.id;
  bot.sendMessage(
    chatId,
    'Simply send me an Instagram Reel link, and I\'ll download and send you the video.\n\nExample link format:\nhttps://www.instagram.com/reel/xyz123/'
  );
});

// Instagram link handler
bot.on('message', async (msg) => {
  const chatId = msg.chat.id;
  const text = msg.text;

  // Check if the message contains an Instagram reel link
  if (text && text.includes('instagram.com/reel/')) {
    try {
      // Send processing message
      const processingMsg = await bot.sendMessage(chatId, 'Processing your request... 🔄');

      // Download the reel
      const result = await InstagramDL(text);
      
      if (!result || !result.url) {
        throw new Error('Could not fetch video URL');
      }

      // Send the video
      await bot.sendVideo(chatId, result.url, {
        caption: '✨ Here\'s your Instagram Reel!'
      });

      // Delete processing message
      await bot.deleteMessage(chatId, processingMsg.message_id);

    } catch (error) {
      console.error('Error:', error);
      bot.sendMessage(
        chatId,
        '❌ Sorry, I couldn\'t download this reel. Please make sure:\n- The link is valid\n- The reel is public\n- The link is from a reel, not a post'
      );
    }
  }
});

console.log('Bot is running...');